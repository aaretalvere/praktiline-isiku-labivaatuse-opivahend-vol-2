# Foundation Build

Initial working system with API and DB.
