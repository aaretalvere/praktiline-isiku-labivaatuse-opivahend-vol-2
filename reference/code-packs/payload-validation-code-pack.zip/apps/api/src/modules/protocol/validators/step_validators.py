from .types import ValidationResult
from .inference import detect_inference
from ..schemas.payload import ProtocolPayload

def validate_person_block(payload: ProtocolPayload) -> ValidationResult:
    result = ValidationResult()
    if not payload.person.full_name:
        result.add_error("required", "Isiku nimi on kohustuslik.", "person.full_name")
    if not payload.person.procedure_status:
        result.add_error("required", "Menetlusseisund on kohustuslik.", "person.procedure_status")
    if not payload.person.identity_verification_basis:
        result.add_error("required", "Isikusamasuse tuvastamise alus on kohustuslik.", "person.identity_verification_basis")
    if not (payload.person.personal_id_code or payload.person.birth_date):
        result.add_error("conditional_required", "Sisesta kas isikukood või sünniaeg.", "person.personal_id_code")
    return result

def validate_tools_block(payload: ProtocolPayload) -> ValidationResult:
    result = ValidationResult()
    if payload.tools.used_tools:
        if not payload.tools.tool_type:
            result.add_error("required", "Tehnikavahendi liik on kohustuslik.", "tools.tool_type")
        if not payload.tools.tool_brand:
            result.add_error("required", "Tehnikavahendi mark on kohustuslik.", "tools.tool_brand")
    return result

def validate_narrative_field(value: str | None, none_found: bool, field_prefix: str) -> ValidationResult:
    result = ValidationResult()
    if not none_found and not value:
        result.add_error("required", "Sisesta kirjeldus või märgi, et midagi ei tuvastatud.", field_prefix)
    for word in detect_inference(value):
        result.add_warning("inference_warning", f"Väldi järelduslikku sõnastust: {word}", field_prefix)
    return result

def validate_step(step_key: str, payload: ProtocolPayload) -> ValidationResult:
    if step_key == "person":
        return validate_person_block(payload)
    if step_key == "tools":
        return validate_tools_block(payload)
    if step_key == "traces":
        return validate_narrative_field(payload.traces.text, payload.traces.none_found, "traces.text")
    if step_key == "features":
        return validate_narrative_field(payload.features.text, payload.features.none_found, "features.text")
    if step_key == "objects":
        return validate_narrative_field(payload.objects.text, payload.objects.none_found, "objects.text")
    return ValidationResult()
