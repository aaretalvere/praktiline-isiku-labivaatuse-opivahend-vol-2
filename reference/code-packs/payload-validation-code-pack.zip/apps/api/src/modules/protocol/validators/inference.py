INFERENCE_WORDS = [
    "tõenäoliselt",
    "ilmselt",
    "arvatavasti",
    "võis tekkida",
    "näib olevat",
    "oletatavasti",
]

def detect_inference(text: str | None) -> list[str]:
    if not text:
        return []
    lowered = text.lower()
    return [word for word in INFERENCE_WORDS if word in lowered]
