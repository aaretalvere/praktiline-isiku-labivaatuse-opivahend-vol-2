from ..schemas.payload import ProtocolPayload
from ..validators.step_validators import validate_step
from ..validators.types import ValidationResult

ALLOWED_STATES_FOR_EDIT = {"draft", "in_progress"}

class ProtocolService:
    def save_payload(self, protocol: dict, patch: dict) -> dict:
        if protocol["state"] not in ALLOWED_STATES_FOR_EDIT:
            raise ValueError("Locked või lõpetatud protokolli ei saa muuta.")
        payload = ProtocolPayload(**protocol.get("payload", {}))
        merged = payload.model_copy(update=patch)
        protocol["payload"] = merged.model_dump()
        return protocol

    def validate_step(self, protocol: dict, step_key: str) -> ValidationResult:
        payload = ProtocolPayload(**protocol.get("payload", {}))
        return validate_step(step_key, payload)

    def move_next(self, protocol: dict, current_step: str, step_order: list[str]) -> dict:
        result = self.validate_step(protocol, current_step)
        if not result.is_valid:
            raise ValueError("Samm ei ole valideeritud.")
        try:
            idx = step_order.index(current_step)
        except ValueError:
            raise ValueError("Tundmatu samm.")
        protocol["current_step"] = step_order[idx + 1] if idx + 1 < len(step_order) else None
        protocol["state"] = "in_progress"
        return protocol

    def submit_protocol(self, protocol: dict, step_order: list[str]) -> dict:
        payload = ProtocolPayload(**protocol.get("payload", {}))
        for step in step_order:
            result = validate_step(step, payload)
            if not result.is_valid:
                raise ValueError(f"Submission validation failed at step: {step}")
        protocol["state"] = "locked"
        return protocol
