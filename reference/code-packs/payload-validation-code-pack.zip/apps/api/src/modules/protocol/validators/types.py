from pydantic import BaseModel, Field
from typing import List, Optional

class ValidationMessage(BaseModel):
    code: str
    field: Optional[str] = None
    message: str

class ValidationResult(BaseModel):
    is_valid: bool = True
    errors: List[ValidationMessage] = Field(default_factory=list)
    warnings: List[ValidationMessage] = Field(default_factory=list)

    def add_error(self, code: str, message: str, field: str | None = None):
        self.is_valid = False
        self.errors.append(ValidationMessage(code=code, field=field, message=message))

    def add_warning(self, code: str, message: str, field: str | None = None):
        self.warnings.append(ValidationMessage(code=code, field=field, message=message))
