from __future__ import annotations
from typing import List, Optional, Literal
from pydantic import BaseModel, Field

class MetaBlock(BaseModel):
    case_number: Optional[str] = None
    place: Optional[str] = None
    date: Optional[str] = None
    started_at: Optional[str] = None
    ended_at: Optional[str] = None

class ComposerBlock(BaseModel):
    title: Optional[str] = None
    full_name: Optional[str] = None

class PersonBlock(BaseModel):
    full_name: Optional[str] = None
    procedure_status: Optional[str] = None
    personal_id_code: Optional[str] = None
    birth_date: Optional[str] = None
    identity_verification_basis: Optional[str] = None

class ParticipantItem(BaseModel):
    role: Optional[str] = None
    full_name: Optional[str] = None
    contact_address: Optional[str] = None

class TranslatorBlock(BaseModel):
    translator_present: bool = False
    full_name: Optional[str] = None
    confirmation_given: bool = False

class ToolsBlock(BaseModel):
    used_tools: bool = False
    tool_type: Optional[str] = None
    tool_brand: Optional[str] = None

class NarrativeBlock(BaseModel):
    text: Optional[str] = None
    none_found: bool = False

class NotesBlock(BaseModel):
    text: Optional[str] = None
    no_notes: bool = False
    reading_mode: Optional[Literal["self_read", "read_aloud"]] = None

class AttachmentItem(BaseModel):
    name: str
    kind: Optional[str] = None

class AttachmentsBlock(BaseModel):
    no_attachments: bool = False
    items: List[AttachmentItem] = Field(default_factory=list)

class FinalizationBlock(BaseModel):
    refusal_to_sign: bool = False
    refusal_reason: Optional[str] = None

class ProtocolPayload(BaseModel):
    meta: MetaBlock = Field(default_factory=MetaBlock)
    composer: ComposerBlock = Field(default_factory=ComposerBlock)
    person: PersonBlock = Field(default_factory=PersonBlock)
    participants: List[ParticipantItem] = Field(default_factory=list)
    translator: TranslatorBlock = Field(default_factory=TranslatorBlock)
    tools: ToolsBlock = Field(default_factory=ToolsBlock)
    traces: NarrativeBlock = Field(default_factory=NarrativeBlock)
    features: NarrativeBlock = Field(default_factory=NarrativeBlock)
    objects: NarrativeBlock = Field(default_factory=NarrativeBlock)
    notes: NotesBlock = Field(default_factory=NotesBlock)
    attachments: AttachmentsBlock = Field(default_factory=AttachmentsBlock)
    finalization: FinalizationBlock = Field(default_factory=FinalizationBlock)
