from fastapi import APIRouter, HTTPException
from ..services.protocol_service import ProtocolService

router = APIRouter(prefix="/protocols", tags=["protocols"])
service = ProtocolService()

_FAKE_DB = {
    "protocol-1": {
        "id": "protocol-1",
        "state": "draft",
        "current_step": "person",
        "payload": {},
    }
}
STEP_ORDER = ["meta", "composer", "person", "participants", "translator", "tools", "traces", "features", "objects", "notes", "attachments", "finalization"]

@router.get("/{protocol_id}")
def get_protocol(protocol_id: str):
    protocol = _FAKE_DB.get(protocol_id)
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    return protocol

@router.patch("/{protocol_id}/payload")
def patch_payload(protocol_id: str, patch: dict):
    protocol = _FAKE_DB.get(protocol_id)
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    try:
        updated = service.save_payload(protocol, patch)
        return updated
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@router.post("/{protocol_id}/validate-step")
def validate_step(protocol_id: str, body: dict):
    protocol = _FAKE_DB.get(protocol_id)
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    step_key = body.get("step_key")
    return service.validate_step(protocol, step_key)

@router.post("/{protocol_id}/next-step")
def next_step(protocol_id: str):
    protocol = _FAKE_DB.get(protocol_id)
    if not protocol:
        raise HTTPException(status_code=404, detail="Protocol not found")
    try:
        updated = service.move_next(protocol, protocol["current_step"], STEP_ORDER)
        return updated
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
