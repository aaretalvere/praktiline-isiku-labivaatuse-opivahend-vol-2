from src.modules.protocol.schemas.payload import ProtocolPayload
from src.modules.protocol.validators.step_validators import validate_person_block

def test_person_requires_id_or_birth_date():
    payload = ProtocolPayload(person={"full_name": "Test", "procedure_status": "kahtlustatav", "identity_verification_basis": "ID kaart"})
    result = validate_person_block(payload)
    assert result.is_valid is False
    assert any(msg.code == "conditional_required" for msg in result.errors)
