# Payload + Validation code pack

See lähtepakett on mõeldud starter-repo järgmise ehitusetapi alusena.
Fookus:
- payload skeemid
- validatorid
- protocol service
- API endpointide skeleton
