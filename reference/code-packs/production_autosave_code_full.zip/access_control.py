
def can_access(user, protocol):
    return user['role']=='admin' or user['id']==protocol['user_id']
