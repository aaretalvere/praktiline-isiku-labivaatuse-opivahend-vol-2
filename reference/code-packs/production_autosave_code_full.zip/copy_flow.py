
def copy_protocol(p):
    return {"state":"draft","payload":p['payload']}
