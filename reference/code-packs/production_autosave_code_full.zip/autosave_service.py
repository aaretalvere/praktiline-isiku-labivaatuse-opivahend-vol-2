
def autosave(protocol, payload):
    if protocol['state']=='locked':
        raise Exception("locked")
    protocol['payload'].update(payload)
    return protocol
