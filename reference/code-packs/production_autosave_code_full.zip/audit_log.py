
def log(action, actor, target):
    return {"action":action,"actor":actor,"target":target}
