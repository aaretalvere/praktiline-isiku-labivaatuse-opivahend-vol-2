def test_export_context_contains_meta():
    protocol = type("Protocol", (), {"id": "1", "state": "locked", "payload": {"meta": {"case_number": "123"}}})()
    assert protocol.payload["meta"]["case_number"] == "123"
