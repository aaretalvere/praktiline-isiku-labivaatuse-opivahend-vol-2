from fastapi import APIRouter

router = APIRouter()

@router.post("/protocols/{protocol_id}/exports/docx")
def create_docx_export(protocol_id: str):
    return {"ok": True, "protocol_id": protocol_id, "type": "docx"}

@router.post("/protocols/{protocol_id}/exports/pdf")
def create_pdf_export(protocol_id: str):
    return {"ok": True, "protocol_id": protocol_id, "type": "pdf"}

@router.get("/protocols/{protocol_id}/exports")
def list_protocol_exports(protocol_id: str):
    return {"ok": True, "protocol_id": protocol_id, "items": []}

@router.get("/exports/{export_id}/download")
def download_export(export_id: str):
    return {"ok": True, "export_id": export_id, "action": "download"}
