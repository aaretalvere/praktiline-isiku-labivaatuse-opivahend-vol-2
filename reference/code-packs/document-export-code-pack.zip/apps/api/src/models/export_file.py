from sqlalchemy import Column, String, DateTime
from sqlalchemy.dialects.postgresql import UUID
from src.core.database import Base

class ExportFile(Base):
    __tablename__ = "export_files"

    id = Column(UUID(as_uuid=True), primary_key=True)
    protocol_id = Column(UUID(as_uuid=True), nullable=False)
    export_type = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    mime_type = Column(String, nullable=False)
    created_by = Column(UUID(as_uuid=True), nullable=False)
    created_at = Column(DateTime, nullable=False)
