from datetime import datetime

class ExportRegistryService:
    def build_record(self, protocol_id, export_type, file_path, mime_type, created_by):
        return {
            "protocol_id": protocol_id,
            "export_type": export_type,
            "file_path": file_path,
            "mime_type": mime_type,
            "created_by": created_by,
            "created_at": datetime.utcnow().isoformat(),
        }
