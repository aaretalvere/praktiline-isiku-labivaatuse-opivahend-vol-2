from typing import Any, Dict

class ExportContextService:
    def build(self, protocol: Any) -> Dict[str, Any]:
        payload = protocol.payload or {}
        return {
            "protocol_id": str(protocol.id),
            "state": protocol.state,
            "meta": payload.get("meta", {}),
            "composer": payload.get("composer", {}),
            "person": payload.get("person", {}),
            "participants": payload.get("participants", []),
            "translator": payload.get("translator", {}),
            "tools": payload.get("tools", {}),
            "traces": payload.get("traces", {}),
            "features": payload.get("features", {}),
            "objects": payload.get("objects", {}),
            "notes": payload.get("notes", {}),
            "attachments": payload.get("attachments", []),
            "finalization": payload.get("finalization", {}),
        }
