export default function ProtocolExportsPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Ekspordid</h1>
      <p>Siin kuvatakse protokolliga seotud DOCX ja PDF failid.</p>
    </main>
  );
}
